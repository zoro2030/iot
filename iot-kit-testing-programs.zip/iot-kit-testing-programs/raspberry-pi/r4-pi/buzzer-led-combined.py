import RPi.GPIO as GPIO

import time

for i in range(24):

    pin = i

    GPIO.setmode(GPIO.BCM)

    GPIO.setwarnings(False)

    GPIO.setup(pin, GPIO.OUT)

    GPIO.output(pin, True)
    
    print(pin)

    print ("Output Device ON")

    time.sleep(5)

    GPIO.cleanup()