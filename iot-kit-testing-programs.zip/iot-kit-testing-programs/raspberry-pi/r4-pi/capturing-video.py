import cv2

def capture_video(output_file='output.avi', frame_width=640, frame_height=480, fps=20):
    # Open the webcam (0 is usually the built-in webcam, 1 or other number for external USB webcam)
    cap = cv2.VideoCapture(0)

    # Set the frame width and height
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, frame_width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, frame_height)

    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(output_file, fourcc, fps, (frame_width, frame_height))

    if not cap.isOpened():
        print("Error: Could not open video device.")
        return

    print("Press 'q' to stop recording")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break

        # Write the frame to the output file
        out.write(frame)

        # Display the frame (optional)
        cv2.imshow('frame', frame)

        # Exit if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release everything if job is finished
    cap.release()
    out.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    capture_video()
