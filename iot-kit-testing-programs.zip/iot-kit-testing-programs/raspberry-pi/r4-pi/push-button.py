import RPi.GPIO as GPIO
import time
pushbuttonPin = 7
pushbuttonPin2 = 8

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(pushbuttonPin, GPIO.IN)
GPIO.setup(pushbuttonPin2, GPIO.IN)

while True:
    if(GPIO.input(pushbuttonPin) == True):
        print("push button 1 is pressed")
        time.sleep(1)
    elif(GPIO.input(pushbuttonPin2) == True):
        print("push button 2 is pressed")
        time.sleep(1)
    else:
         print("push button is not pressed")
         time.sleep(1)

GPIO.cleanup()