#include <ESP8266HTTPClient.h>
//#include <b64.h>
//#include <HttpClient.h>
#include <Esp.h>
#include <ESP8266WiFi.h>

String _macaddress;

String _cloudstore = "https://www.cognifront.com/apps/iotcloud/cloud-store.php";
String _cloudretrieve = "https://www.cognifront.com/apps/iotcloud/cloud-retrieve.php";
String _tmpUrl, _tmpResponse, _apikey;

HTTPClient _coghttpReq;
WiFiClient _cogwificlient;

typedef struct _cogpinbinding
{
  int pin;
  char variable[16];
} _cogpinbinding;
_cogpinbinding _cogbindings[5];
byte _cogbindingcursor = 0;

String _urlencode (String str);
String cogRetrieveCloudVariable (String variable);


void cogInitCloud (String ssid, String pass, String apikey)
{
	WiFi.mode(WIFI_STA);
	_macaddress = WiFi.macAddress();
	WiFi.begin(ssid.c_str(), pass.c_str());
  Serial.print ("Connecting to ");
  Serial.println (ssid);
	while (WiFi.status() != WL_CONNECTED)
		delay(275);
  Serial.println ("connected successfully");
	_apikey = apikey;
}

void cogBindPin (int pin, char * variable)
{
	_cogbindings[_cogbindingcursor].pin = pin;
	memcpy(_cogbindings[_cogbindingcursor].variable, variable, strlen(variable));
	if (_cogbindingcursor<4) _cogbindingcursor++;
}

void cogAppLoop ()
{
	for (int i = 0; i < _cogbindingcursor; i++)
	{
		String value = cogRetrieveCloudVariable(_cogbindings[i].variable);
		int _op = HIGH;
		if (value.equals("HIGH")) _op = HIGH;
		if (value.equals("LOW")) _op = LOW;
		if (_cogbindings[i].pin == BUILTIN_LED) _op = !_op;
		digitalWrite(_cogbindings[i].pin,_op);
	}
}

void cogStoreCloudVariable (String variable,String value)
{
	_tmpUrl = _cloudstore + "?apikey=" + _apikey + "&variable=" + _urlencode(variable) + "&value=" + _urlencode(value);
	Serial.println(_tmpUrl);
	_coghttpReq.begin (_cogwificlient,_tmpUrl.c_str());
    delay (30);
    int httpRespCode = _coghttpReq.GET();
	_tmpResponse = _coghttpReq.getString();
    Serial.print (httpRespCode);
	Serial.print (" : ");
	Serial.println (_tmpResponse);
    _coghttpReq.end();
}

String cogRetrieveCloudVariable (String variable)
{
	_tmpUrl = _cloudretrieve + "?apikey=" + _apikey + "&variable=" + _urlencode(variable);
	Serial.println(_tmpUrl);
	_coghttpReq.begin (_cogwificlient,_tmpUrl.c_str());
    delay (30);
    int httpRespCode = _coghttpReq.GET();
	_tmpResponse = _coghttpReq.getString();
    Serial.print (httpRespCode);
	Serial.print (" : ");
	Serial.println (_tmpResponse);
    _coghttpReq.end();
	return _tmpResponse;
}

String _urlencode (String str)
{
  String encodedString="";
  char c;
  char code0;
  char code1;
  char code2;
  for (int i =0; i < str.length(); i++)
  {
    c=str.charAt(i);
    if (c == ' '){
      encodedString+= '+';
    } else if (isalnum(c)){
      encodedString+=c;
    } else{
      code1=(c & 0xf)+'0';
      if ((c & 0xf) >9){
          code1=(c & 0xf) - 10 + 'A';
      }
      c=(c>>4)&0xf;
      code0=c+'0';
      if (c > 9){
          code0=c - 10 + 'A';
      }
      code2='\0';
      encodedString+='%';
      encodedString+=code0;
      encodedString+=code1;
      //encodedString+=code2;
    }
    yield();
  }
  return encodedString;
}
